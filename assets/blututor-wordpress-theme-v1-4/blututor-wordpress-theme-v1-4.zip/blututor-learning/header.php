<!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="<?php echo esc_attr( get_bloginfo( 'description' ) ?: 'Personalized homework, textbook, and test-prep support from Blututor.' ); ?>">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<header class="site-header"><div class="container nav-wrap">
<a class="brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="Blututor home"><span class="cap" aria-hidden="true">🎓</span><span>Blu<span class="brand-red">tutor</span></span></a>
<button class="menu-toggle" type="button" aria-expanded="false" aria-controls="primary-nav" aria-label="Open navigation">☰</button>
<nav class="primary-nav" id="primary-nav" aria-label="Primary navigation"><a class="active" href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a><a href="#subjects">Books</a><a href="#how">How it Works</a></nav>
<div class="nav-actions"><a class="button button-light" href="#how" data-toast="Live demo preview coming soon.">▣ Live Demo</a><a class="button button-navy" href="#tutor" data-toast="Tutor applications are coming soon.">Become a Tutor</a></div>
</div></header>
