<?php get_header(); ?>
<main id="primary">
<section class="hero" id="home"><div class="container hero-grid">
<div class="hero-copy"><h1>Human Expertise.<br>AI Intelligence.<br><span>Better Learning.</span></h1>
<p class="intro">Access top subject experts for personalized homework, textbook walkthroughs, and testing support for learners of all grade levels—anytime. anywhere.</p>
<a class="button button-red button-large" href="#how">Find Your Tutor <b aria-hidden="true">→</b></a></div>
<div class="hero-art"><img src="<?php echo blututor_learning_image( 'hero-tutoring.jpg' ); ?>" alt="Student talking with a tutor during an online lesson"></div>
</div></section>

<section class="steps-section" id="how"><div class="container">
<div class="section-heading"><h2>Get Homework Help Anytime. Anywhere.</h2><p>Personalized help with homework, studies, and test prep—on your schedule.</p></div>
<div class="steps-grid">
<article class="step-card"><div class="step-top"><span class="step-icon" aria-hidden="true">⌕</span><span class="step-number">1</span></div><h3>Choose Your Subject</h3><p>Pick what you need help with, from 200+ subjects.</p></article>
<article class="step-card"><div class="step-top"><span class="step-icon" aria-hidden="true">♟</span><span class="step-number">2</span></div><h3>Get Matched</h3><p>We connect you with a qualified tutor in minutes.</p></article>
<article class="step-card"><div class="step-top"><span class="step-icon" aria-hidden="true">ϟ</span><span class="step-number">3</span></div><h3>Start Learning</h3><p>Chat, share files, or book a session — get help fast.</p></article>
</div></div></section>

<section class="support-section" id="subjects"><div class="container support-card">
<div class="student-photo"><img src="<?php echo blututor_learning_image( 'student-studying.jpg' ); ?>" alt="Student completing homework at a laptop"></div>
<div class="support-copy"><h2>Support for<br>Every Learner</h2><p>Whether it’s homework, test prep, or mastering a tough concept, Blututor is here to help.</p>
<ul><li><span class="check">✓</span>Homework Help</li><li><span class="check">✓</span>Test Preparation</li><li><span class="check">✓</span>1:1 or Small Group Sessions</li><li><span class="check">✓</span>Support for All Grade Levels</li></ul></div>
</div></section>

<section class="parents-section"><div class="container">
<div class="section-heading"><h2>Trusted by Parents</h2><p>Real stories. Real progress.</p></div>
<div class="quote-wrap"><button class="round-arrow" type="button" aria-label="Previous testimonial">‹</button>
<div class="quote-card"><img src="<?php echo blututor_learning_image( 'parent-testimonial.jpg' ); ?>" alt="Parent testimonial portrait">
<blockquote>“Blututor has been a game-changer for our family. My daughter’s grades have improved, and she actually looks forward to homework now!”<cite>— Jessica L., Parent</cite></blockquote><div class="stars" aria-label="5 out of 5 stars">★★★★★</div></div>
<button class="round-arrow" type="button" aria-label="Next testimonial">›</button></div>
<div class="partner-logos" aria-label="Education brand examples"><span>Kaplan</span><span class="princeton">The Princeton<br>Review®</span><span class="mcgraw">McGraw Hill</span><span class="pearson">Ⓟ Pearson</span><span class="barrons">BARRON’S</span><span class="ets">ETS®</span></div>
</div></section>

<section class="benefits" aria-label="Blututor benefits"><div class="container benefit-grid">
<div class="benefit"><span class="benefit-icon" aria-hidden="true">◧</span><p><strong>200+ Subjects</strong><small>All grades</small></p></div>
<div class="benefit"><span class="benefit-icon" aria-hidden="true">◴</span><p><strong>Fast Matching</strong><small>Minutes</small></p></div>
<div class="benefit"><span class="benefit-icon" aria-hidden="true">⬟</span><p><strong>Secure &amp; Safe</strong><small>Private</small></p></div>
<div class="benefit"><span class="benefit-icon" aria-hidden="true">◆</span><p><strong>Affordable Plans</strong><small>Flexible</small></p></div>
</div></section>
</main>
<?php get_footer(); ?>
