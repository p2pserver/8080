BLUTUTOR LEARNING WORDPRESS THEME — VERSION 1.4.0
================================================
INSTALL
1. In WordPress Admin, open Appearance > Themes > Add New Theme > Upload Theme.
2. Upload blututor-wordpress-theme-v1-4.zip, click Install Now, then Activate.
3. Visit the site's front page.

FIXES IN THIS VERSION
- Set the entire page background to white, including hero, homework cards, support section, and testimonial section.
- Replaced the hero artwork with a clean photo crop from the approved reference.
- Removed decorative sketches, text overlays, and the floating tutor card over the hero image.
- Made the support panel use a balanced 50/50 grid with intrinsic height and no absolute positioning, preventing skew and content overlap.
- Removed the extra overlapping heading/content that could appear beneath the support panel.
- Fixed testimonial image sizing with a complete square crop, explicit dimensions, object-fit, and a circular frame.
- Kept all content in normal document flow, with responsive mobile layouts.
- Included local image files, CSS, JavaScript, and WordPress PHP templates.

NOTE
The photos are crops from the supplied design reference because the original photo source files were not provided. Replace them with originals if available for maximum clarity. CTA actions remain visual placeholders and should be connected to BluTutor Core workflows before launch.
