<div class="toast" role="status" aria-live="polite"></div>
<footer class="site-footer" id="tutor"><div class="container footer-grid">
<div class="footer-brand"><a class="brand" href="<?php echo esc_url( home_url( '/' ) ); ?>"><span class="cap" aria-hidden="true">🎓</span><span>Blu<span class="brand-red">tutor</span></span></a><p>Online homework, textbook, and test support • 24/7<br>Helping learners succeed, one question at a time.</p></div>
<div class="footer-col"><h3>Quick Links</h3><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a><a href="#subjects">Books</a><a href="#how">How it Works</a><a href="#tutor">Become a Tutor</a></div>
<div class="footer-col"><h3>Support</h3><a href="#support">Help Center</a><a href="mailto:hello@blututor.com">Contact Us</a><a href="#how">FAQ</a><a href="#privacy">Privacy Policy</a></div>
<div class="footer-col"><h3>Connect</h3><div class="social-row"><a href="#" aria-label="Facebook">f</a><a href="#" aria-label="Twitter">♥</a><a href="#" aria-label="Instagram">◎</a><a href="#" aria-label="LinkedIn">in</a><a href="#" aria-label="YouTube">▶</a></div></div>
</div><div class="container footer-bottom"><span>© <?php echo esc_html( wp_date( 'Y' ) ); ?> Blututor • All rights reserved.</span><nav aria-label="Legal links"><a href="#terms">Terms</a><a href="#privacy">Privacy</a><a href="#accessibility">Accessibility</a></nav></div></footer>
<?php wp_footer(); ?></body></html>
