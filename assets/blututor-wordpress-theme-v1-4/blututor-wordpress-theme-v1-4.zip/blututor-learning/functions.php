<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
function blututor_learning_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'html5', array( 'search-form', 'gallery', 'caption', 'style', 'script' ) );
    register_nav_menus( array( 'primary' => __( 'Primary Navigation', 'blututor' ) ) );
}
add_action( 'after_setup_theme', 'blututor_learning_setup' );
function blututor_learning_assets() {
    wp_enqueue_style( 'blututor-inter', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap', array(), null );
    wp_enqueue_style( 'blututor-learning-style', get_stylesheet_uri(), array(), '1.4.0' );
    wp_enqueue_script( 'blututor-learning-script', get_template_directory_uri() . '/assets/js/blututor.js', array(), '1.4.0', true );
}
add_action( 'wp_enqueue_scripts', 'blututor_learning_assets' );
function blututor_learning_image( $file ) {
    return esc_url( get_template_directory_uri() . '/assets/images/' . $file );
}
