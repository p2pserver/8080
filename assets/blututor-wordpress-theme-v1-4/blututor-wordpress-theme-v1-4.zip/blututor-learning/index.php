<?php get_header(); ?><main class="container" style="padding-block:40px">
<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?><article <?php post_class(); ?>><h1><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1><div><?php the_content(); ?></div></article><?php endwhile; else : ?><h1><?php esc_html_e( 'Nothing found', 'blututor' ); ?></h1><?php endif; ?>
</main><?php get_footer(); ?>
